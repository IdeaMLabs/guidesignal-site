# GuideSignal Firebase Auth Integration

This package contains the instructions and code snippets needed to update `signupSigninFix.js`.

## Steps

1. Open `signupSigninFix.js` in your repository.
2. Replace the existing `fetch('/api/auth/signup', ...)` block with:

```
// Firebase sign-up using REST API
const response = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyBJOVbMoHfdxHexsfqsbYsvFzFqaKBXC_s', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: formData.email,
    password: formData.password,
    returnSecureToken: true
  })
});

if (response.ok) {
  const result = await response.json();
  if (result.idToken) {
    localStorage.setItem('authToken', result.idToken);
  }
}

```

3. Replace the existing `fetch('/api/auth/signin', ...)` block with:

```
// Firebase sign-in using REST API
const response = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyBJOVbMoHfdxHexsfqsbYsvFzFqaKBXC_s', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: email,
    password: pwd,
    returnSecureToken: true
  })
});

if (response.ok) {
  const result = await response.json();
  if (result.idToken) {
    localStorage.setItem('authToken', result.idToken);
  }
}

```

4. Remove the `'Accept': 'application/json'` header and the `timestamp` field, as Firebase does not need them.

5. Commit and push the changes.

---

After this update, users will be able to sign up and sign in with Firebase Authentication, and the session token will be saved to `localStorage`.
